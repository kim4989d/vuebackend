package com.base.webapp.application;

import java.util.Hashtable;

public class Hash_1 {
	public String name;
	public int age;
	public String address;
	public String email;

	public void setName(String name) {
		this.name = name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public static void main(String[] args) {

		Hashtable table = new Hashtable();
		
		table.put(1,table);
		
		
		
		
		
		
		

	}

}
